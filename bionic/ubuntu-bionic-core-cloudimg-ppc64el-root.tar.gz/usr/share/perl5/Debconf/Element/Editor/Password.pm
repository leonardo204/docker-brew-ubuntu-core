#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::Element::Editor::Password;
use strict;
use base qw(Debconf::Element::Editor::String);


1
